---
name: Kinetic Operator
colors:
  surface: '#f9f9ff'
  surface-dim: '#cbdaff'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e0e8ff'
  surface-container-highest: '#d8e2ff'
  on-surface: '#0a1b38'
  on-surface-variant: '#424654'
  inverse-surface: '#21304e'
  inverse-on-surface: '#edf0ff'
  outline: '#737785'
  outline-variant: '#c3c6d6'
  surface-tint: '#0357cf'
  primary: '#0047ae'
  on-primary: '#ffffff'
  primary-container: '#1a5fd7'
  on-primary-container: '#dde4ff'
  inverse-primary: '#b1c5ff'
  secondary: '#ae2a00'
  on-secondary: '#ffffff'
  secondary-container: '#da3700'
  on-secondary-container: '#fffbff'
  tertiary: '#893200'
  on-tertiary: '#ffffff'
  tertiary-container: '#b04300'
  on-tertiary-container: '#ffded1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b1c5ff'
  on-primary-fixed: '#001947'
  on-primary-fixed-variant: '#00419f'
  secondary-fixed: '#ffdbd1'
  secondary-fixed-dim: '#ffb5a1'
  on-secondary-fixed: '#3c0800'
  on-secondary-fixed-variant: '#881f00'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#f9f9ff'
  on-background: '#0a1b38'
  surface-variant: '#d8e2ff'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  status-xl:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '800'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  touch-target: 48px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style

This design system is engineered for high-stakes, live-event environments where speed and reliability are paramount. The aesthetic merges **Corporate Modern** efficiency with **High-Contrast** utility, ensuring that booth operators can monitor hardware status and manage guest flows at a glance under challenging lighting—from dimly lit ballrooms to bright outdoor marquees.

The personality is authoritative and tech-forward, utilizing a "Dashboard-First" philosophy. By combining a systematic layout with bold, expressive status indicators, the UI evokes a sense of "mission control" confidence. Elements are structured with precision, utilizing a clean, utilitarian interface that prioritizes functional clarity over decorative flourish.

## Colors

The palette is anchored by a high-contrast foundation to maximize legibility. 

- **Primary Blue (#1A5FD7)**: Used for primary actions, active states, and navigation branding. It represents the "reliable" core of the application.
- **Secondary Orange/Red (#EF3F04)**: Reserved exclusively for critical alerts, stop-actions, and live recording indicators to ensure immediate visual heat.
- **Dark Navy (#21304E)**: Provides a deep, high-contrast base for all text and iconography, replacing pure black for a more refined, professional appearance.
- **Background Gray (#F1F1F1)**: A neutralized surface that reduces screen glare compared to pure white, serving as a clean stage for high-contrast UI cards.

## Typography

Typography is used as a structural tool to define hierarchy. 

- **Headlines (Hanken Grotesk)**: Chosen for its sharp, contemporary geometry. Use Bold and ExtraBold weights for hardware status and session timers to ensure visibility from a distance.
- **Body (Inter)**: The workhorse for settings, logs, and configuration. Its high x-height maintains legibility in dense data tables.
- **Labels (JetBrains Mono)**: Utilized for technical readouts, file paths, and camera metadata (ISO, Shutter, Aperture), providing a distinct "tech-forward" and precise aesthetic.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a strict 8px baseline rhythm. Given the operator context, touch targets are prioritized.

- **Grid**: Use a 12-column layout for desktop monitoring and a 4-column layout for mobile/tablet remote access.
- **Touch Targets**: No interactive element should be smaller than 48x48px to accommodate rapid interaction during events.
- **Information Density**: High density is permitted in the central dashboard area, but must be balanced by wide 24px gutters to prevent visual crowding and accidental taps.

## Elevation & Depth

This design system uses **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows to maintain a flat, professional, and high-performance look.

- **Level 0 (Background)**: #F1F1F1.
- **Level 1 (Cards)**: Pure White (#FFFFFF) with a 1px solid border in #D1D5DB. No shadow.
- **Level 2 (Modals/Overlays)**: Pure White with a sharp, high-diffusion shadow (0px 10px 15px -3px rgba(33, 48, 78, 0.1)) to lift the element from the dashboard grid.
- **Active State**: Elements being interacted with should gain a 2px primary blue border rather than a shadow.

## Shapes

A **Soft (0.25rem)** roundedness is applied to all UI elements. This subtle rounding maintains the professional, precise feel of the application while making the interface feel modern and accessible. 

- **Small elements** (Inputs, Checkboxes): 4px radius.
- **Large elements** (Cards, Main Action Buttons): 8px radius.
- **Status Pills**: 9999px (full pill) to differentiate them from interactive buttons.

## Components

### Buttons
- **Primary**: Solid Primary Blue with White text. Bold weight. High-contrast.
- **Critical**: Solid Secondary Red. Used for "Emergency Stop" or "Reset Session."
- **Ghost**: Primary Blue outline with transparent background for secondary settings.

### Status Indicators
- Use large, bold Hanken Grotesk text. 
- Pair text with a "Pulse" icon for live hardware (e.g., "CAMERA: ONLINE" with a green pulsing dot).

### Input Fields
- Structured with a Dark Navy label (Label-Mono) and a 1px border. 
- Focus state uses a 2px Primary Blue border.

### Hardware Cards
- Use for Camera, Printer, and Lighting status. 
- Feature a large icon in the top left and a high-contrast status badge in the top right.

### Progress Bars
- High-contrast bars (Primary Blue on Light Gray track) to show "Printing" or "Uploading" status clearly from across a room.